package Console;

public class Produit {
   private String nom; 
   private String description; 

   public Produit(String nom, String description) {
      this.nom = nom;
      this.description = description;
   }

   public String getNom() {
      return this.nom;
   }

   public void setNom(String nom) {
      this.nom = nom;
   }

   public String getDescription() {
      return this.description;
   }

   public void setDescription(String description) {
      this.description = description;
   }

   public String toString() {
      return "Produit [nom = " + this.nom + ", description = " + this.description + " ]\n\t";
   }
}
